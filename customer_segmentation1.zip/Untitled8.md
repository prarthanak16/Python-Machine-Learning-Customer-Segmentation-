```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
%matplotlib inline
```


```python
cust=pd.read_csv("Mall_Customers.csv")
```


```python
cust.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CustomerID</th>
      <th>Gender</th>
      <th>Age</th>
      <th>Annual Income (k$)</th>
      <th>Spending Score (1-100)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Male</td>
      <td>19</td>
      <td>15</td>
      <td>39</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>Male</td>
      <td>21</td>
      <td>15</td>
      <td>81</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>Female</td>
      <td>20</td>
      <td>16</td>
      <td>6</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>Female</td>
      <td>23</td>
      <td>16</td>
      <td>77</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>Female</td>
      <td>31</td>
      <td>17</td>
      <td>40</td>
    </tr>
  </tbody>
</table>
</div>




```python
cust.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 200 entries, 0 to 199
    Data columns (total 5 columns):
     #   Column                  Non-Null Count  Dtype 
    ---  ------                  --------------  ----- 
     0   CustomerID              200 non-null    int64 
     1   Gender                  200 non-null    object
     2   Age                     200 non-null    int64 
     3   Annual Income (k$)      200 non-null    int64 
     4   Spending Score (1-100)  200 non-null    int64 
    dtypes: int64(4), object(1)
    memory usage: 7.9+ KB
    


```python
cust.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CustomerID</th>
      <th>Age</th>
      <th>Annual Income (k$)</th>
      <th>Spending Score (1-100)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>200.000000</td>
      <td>200.000000</td>
      <td>200.000000</td>
      <td>200.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>100.500000</td>
      <td>38.850000</td>
      <td>60.560000</td>
      <td>50.200000</td>
    </tr>
    <tr>
      <th>std</th>
      <td>57.879185</td>
      <td>13.969007</td>
      <td>26.264721</td>
      <td>25.823522</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>18.000000</td>
      <td>15.000000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>50.750000</td>
      <td>28.750000</td>
      <td>41.500000</td>
      <td>34.750000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>100.500000</td>
      <td>36.000000</td>
      <td>61.500000</td>
      <td>50.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>150.250000</td>
      <td>49.000000</td>
      <td>78.000000</td>
      <td>73.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>200.000000</td>
      <td>70.000000</td>
      <td>137.000000</td>
      <td>99.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
sns.jointplot(x='Age',y='Annual Income (k$)',data=cust)
```




    <seaborn.axisgrid.JointGrid at 0x2386db0fb08>




![png](output_5_1.png)



```python
sns.jointplot(x='Age',y='Spending Score (1-100)',data=cust,color='green',kind='kde')
```




    <seaborn.axisgrid.JointGrid at 0x2386dc61dc8>




![png](output_6_1.png)



```python
plt.figure(figsize=(14,5))
plt.subplot(1,2,1)
sns.boxplot(y=cust["Spending Score (1-100)"],color="brown")
plt.subplot(1,2,2)
sns.boxplot(y=cust["Annual Income (k$)"],color="yellow")
plt.show()
```


![png](output_7_0.png)



```python
sns.pairplot(cust,hue='Gender',palette='Set1')
```




    <seaborn.axisgrid.PairGrid at 0x2386de8fd48>




![png](output_8_1.png)



```python
gender=cust.Gender.value_counts()
sns.barplot(x=gender.index,y=gender.values)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x2386e749e48>




![png](output_9_1.png)



```python
fig = plt.figure()
pct=round(gender/sum(gender)*100)
ax = fig.add_axes([0,0,1,1])
ax.axis('equal')

lbs=['Female','Male']
ax.pie(pct,labels=lbs,autopct='%1.2f%%')
plt.show()
```


![png](output_10_0.png)



```python
age0=cust.Age[(cust.Age<20)]
age1= cust.Age[(cust.Age>=20)&(cust.Age<=30)]
age2=cust.Age[(cust.Age>30)&(cust.Age<=40)]
age3=cust.Age[(cust.Age>40)&(cust.Age<=50)]
age4=cust.Age[(cust.Age>50)&(cust.Age<=60)]
age5=cust.Age[(cust.Age>60)]
x=['Below 20','21-30','31-40','41-50','51-60','60+']
y=[len(age0.values),len(age1.values),len(age2.values),len(age3.values),len(age4.values),len(age5.values)]
sns.barplot(x=x,y=y,palette='Accent')
plt.title(str("Number of customers based on Age Group"))
plt.xlabel(str("Age"))
plt.ylabel(str("Number of customers"))
plt.show()
```


![png](output_11_0.png)



```python
plt.figure(figsize=(15,7))
income0=cust["Annual Income (k$)"][(cust["Annual Income (k$)"]<15)]
income1=cust["Annual Income (k$)"][(cust["Annual Income (k$)"]>=15)&(cust["Annual Income (k$)"]<=30)]
income2=cust["Annual Income (k$)"][(cust["Annual Income (k$)"]>30)&(cust["Annual Income (k$)"]<=45)]
income3=cust["Annual Income (k$)"][(cust["Annual Income (k$)"]>45)&(cust["Annual Income (k$)"]<=60)]
income4=cust["Annual Income (k$)"][(cust["Annual Income (k$)"]>60)&(cust["Annual Income (k$)"]<=75)]
income5=cust["Annual Income (k$)"][(cust["Annual Income (k$)"]>75)&(cust["Annual Income (k$)"]<=90)]
income6=cust["Annual Income (k$)"][(cust["Annual Income (k$)"]>90)&(cust["Annual Income (k$)"]<=105)]
income7=cust["Annual Income (k$)"][(cust["Annual Income (k$)"]>105)&(cust["Annual Income (k$)"]<=120)]
income8=cust["Annual Income (k$)"][(cust["Annual Income (k$)"]>120)&(cust["Annual Income (k$)"]<=135)]
income9=cust["Annual Income (k$)"][(cust["Annual Income (k$)"]>135)&(cust["Annual Income (k$)"]<=150)]
x=['Below 15','15-30','31-45','46-60','61-75','76-90','91-105','106-120','121-135','136-150']
y=[len(income0.values),len(income1.values),len(income2.values),len(income3.values),len(income4.values),len(income5.values),len(income6.values),len(income7.values),len(income8.values),len(income9.values)]
sns.barplot(x=x,y=y)

plt.title("Number of Customers based on Annual Income")
plt.xlabel("Annual income(k$)")
plt.ylabel("Number of customers")
```




    Text(0, 0.5, 'Number of customers')




![png](output_12_1.png)



```python
spend0=cust["Spending Score (1-100)"][(cust["Spending Score (1-100)"]>0)&(cust["Spending Score (1-100)"]<=20)]
spend1=cust["Spending Score (1-100)"][(cust["Spending Score (1-100)"]>20)&(cust["Spending Score (1-100)"]<=40)]
spend2=cust["Spending Score (1-100)"][(cust["Spending Score (1-100)"]>40)&(cust["Spending Score (1-100)"]<=60)]
spend3=cust["Spending Score (1-100)"][(cust["Spending Score (1-100)"]>60)&(cust["Spending Score (1-100)"]<=80)]
spend4=cust["Spending Score (1-100)"][(cust["Spending Score (1-100)"]>80)&(cust["Spending Score (1-100)"]<=100)]
x=['0-20','21-40','41-60','61-80','81-100']
y=[len(spend0.values),len(spend1.values),len(spend2.values),len(spend3.values),len(spend4.values)]
sns.barplot(x=x,y=y,palette='gist_rainbow')
```




    <matplotlib.axes._subplots.AxesSubplot at 0x2386e9af588>




![png](output_13_1.png)



```python
from sklearn.model_selection import train_test_split
```


```python
X=cust.drop('Gender',axis=1)
```


```python
y=cust['Gender']
```


```python
X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.30)
```


```python
from sklearn.tree import DecisionTreeClassifier
```


```python
dtree=DecisionTreeClassifier()
```


```python
dtree.fit(X_train,y_train)
```




    DecisionTreeClassifier(ccp_alpha=0.0, class_weight=None, criterion='gini',
                           max_depth=None, max_features=None, max_leaf_nodes=None,
                           min_impurity_decrease=0.0, min_impurity_split=None,
                           min_samples_leaf=1, min_samples_split=2,
                           min_weight_fraction_leaf=0.0, presort='deprecated',
                           random_state=None, splitter='best')




```python
predictions=dtree.predict(X_test)
```


```python
from sklearn.metrics import classification_report,confusion_matrix
```


```python
print(classification_report(y_test,predictions))
```

                  precision    recall  f1-score   support
    
          Female       0.64      0.68      0.66        31
            Male       0.63      0.59      0.61        29
    
        accuracy                           0.63        60
       macro avg       0.63      0.63      0.63        60
    weighted avg       0.63      0.63      0.63        60
    
    


```python
print(confusion_matrix(y_test,predictions))
```

    [[21 10]
     [12 17]]
    


```python
from sklearn.cluster import KMeans
```


```python
wcss=[]
gender=cust.Gender.value_counts()
for k in range(1,11):
  kmeans=KMeans(n_clusters=k)
  kmeans.fit(cust.iloc[:,2:])
  wcss.append(kmeans.inertia_)
```


```python
plt.grid()
plt.plot(range(1,11),wcss, linewidth=1, color="red", marker ="8")
plt.xlabel("K Value")
plt.title("Within-Cluster-of-Squares ")
plt.xticks(np.arange(1,11,1))
plt.ylabel("WCSS")
plt.show()
```


![png](output_27_0.png)



```python
kmeans.labels_
```




    array([9, 5, 4, 5, 9, 5, 4, 5, 4, 5, 4, 5, 4, 5, 4, 5, 9, 5, 4, 5, 9, 5,
           4, 5, 4, 5, 9, 9, 9, 5, 4, 5, 4, 5, 4, 5, 4, 5, 9, 5, 1, 5, 9, 9,
           9, 5, 1, 9, 9, 9, 1, 2, 2, 1, 1, 9, 1, 1, 2, 1, 1, 2, 1, 1, 1, 2,
           6, 1, 2, 2, 1, 6, 1, 1, 1, 2, 6, 6, 2, 6, 1, 6, 1, 6, 2, 6, 1, 2,
           2, 6, 1, 2, 6, 6, 2, 2, 6, 2, 6, 2, 2, 6, 1, 2, 6, 2, 1, 6, 1, 1,
           1, 2, 6, 2, 2, 2, 1, 6, 6, 6, 2, 6, 6, 7, 2, 7, 6, 7, 3, 7, 3, 7,
           2, 7, 3, 7, 3, 7, 3, 7, 3, 7, 2, 7, 3, 7, 6, 7, 3, 7, 3, 7, 3, 7,
           3, 7, 3, 7, 3, 7, 6, 7, 3, 7, 3, 7, 3, 7, 3, 7, 3, 7, 3, 7, 3, 7,
           3, 7, 3, 0, 8, 0, 8, 0, 8, 0, 8, 0, 8, 0, 8, 0, 8, 0, 8, 0, 8, 0,
           8, 0])




```python
km = KMeans(n_clusters=5)
clusters = km.fit_predict(cust.iloc[:,2:])
cust["label"] = clusters

from mpl_toolkits.mplot3d import Axes3D

fig = plt.figure(figsize=(25,15))
ax = fig.add_subplot(111, projection='3d')
ax.scatter(cust.Age[cust.label == 0], cust["Annual Income (k$)"][cust.label == 0], cust["Spending Score (1-100)"][cust.label == 0], c='blue', s=60)
ax.scatter(cust.Age[cust.label == 1], cust["Annual Income (k$)"][cust.label == 1], cust["Spending Score (1-100)"][cust.label == 1], c='red', s=60)
ax.scatter(cust.Age[cust.label == 2], cust["Annual Income (k$)"][cust.label == 2], cust["Spending Score (1-100)"][cust.label == 2], c='green', s=60)
ax.scatter(cust.Age[cust.label == 3], cust["Annual Income (k$)"][cust.label == 3], cust["Spending Score (1-100)"][cust.label == 3], c='orange', s=60)
ax.scatter(cust.Age[cust.label == 4], cust["Annual Income (k$)"][cust.label == 4], cust["Spending Score (1-100)"][cust.label == 4], c='purple', s=60)
ax.view_init(30, 185)
plt.xlabel("Age")
plt.ylabel("Annual Income (k$)")
ax.set_zlabel('Spending Score (1-100)')

```




    Text(0.5, 0, 'Spending Score (1-100)')




![png](output_29_1.png)



```python

```
